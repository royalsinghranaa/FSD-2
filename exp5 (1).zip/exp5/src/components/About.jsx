export default function About() {
  return (
    <div>
      <h3>About Component</h3>
      <p>This component is loaded lazily.</p>
    </div>
  );
}
